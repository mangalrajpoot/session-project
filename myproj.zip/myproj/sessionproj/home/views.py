from django.shortcuts import render,redirect
from .models import Register

# Create your views here.
def index(request):
    if request.method=='GET':
        return render(request,'home/index.html')
    else:
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        data=Register(username=username,email=email,password=password)
        data.save()
        return render(request,'home/index.html',{'m':'Account Created Success !'})
    
def login(request):
    if request.method=='GET':
        return render(request,'home/login.html')
    else:
        username=request.POST['username']
        request.session['user']=username
        password=request.POST['password']
        request.session['pass']=password
        data=Register.objects.filter(username=username,password=password)
        if data.count()>0:
            return redirect('profile')
        else:
            return render(request,'home/login.html',{'m':'Invalid Username or Password'})
        
def profile(request):
    username=request.session.get('user')
    password=request.session.get('pass')
    obj=Register.objects.get(username=username,password=password)
    if username:
        return render(request,'home/profile.html',{'user':username,'object':obj})
    else:
        return render(request,'home/login.html',{'m':'Invalid Session Key'})
    
def logout(request):
    del request.session['user']
    return redirect('login')

        

    


